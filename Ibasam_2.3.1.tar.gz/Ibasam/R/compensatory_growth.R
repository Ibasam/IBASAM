compensatory_growth <-
function () 
{
    .C("compensatory_growth", PACKAGE = "Ibasam")
    invisible(NULL)
}
