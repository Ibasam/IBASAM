emergence <-
function () 
{
    .C("emergence", PACKAGE = "Ibasam")
    invisible(NULL)
}
