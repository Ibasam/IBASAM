summer <-
function () 
{
    .C("summer", PACKAGE = "Ibasam")
    invisible(NULL)
}
