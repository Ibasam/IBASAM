go_summer <-
function () 
{
    .C("go_summer", PACKAGE = "Ibasam")
    invisible(NULL)
}
