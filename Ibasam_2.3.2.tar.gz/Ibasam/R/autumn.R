autumn <-
function () 
{
    .C("autumn", PACKAGE = "Ibasam")
    invisible(NULL)
}
