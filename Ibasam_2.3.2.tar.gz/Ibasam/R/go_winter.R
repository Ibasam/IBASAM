go_winter <-
function () 
{
    .C("go_winter", PACKAGE = "Ibasam")
    invisible(NULL)
}
