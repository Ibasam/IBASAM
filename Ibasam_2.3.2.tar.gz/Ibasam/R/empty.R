empty <-
function () 
{
    .C("empty", PACKAGE = "Ibasam")
    invisible(NULL)
}
